# nemesis-android
Nemesis-tinder-like android application for the Solarapparel demo store of the nemesis platform.
